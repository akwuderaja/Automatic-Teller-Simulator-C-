﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Automatic_Teller_Simulator.Classes
{
    internal class savingsAccounts
    {
        public bool Add(string indexOrKey)
        {
            return true;
        }
    }
}
